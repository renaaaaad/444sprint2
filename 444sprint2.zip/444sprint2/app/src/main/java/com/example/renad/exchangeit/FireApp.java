package com.example.renad.exchangeit;

import android.app.Application;

import com.google.firebase.FirebaseApp;

public class FireApp extends Application {

    public void onCreat(){
        super.onCreate();

    }

}
